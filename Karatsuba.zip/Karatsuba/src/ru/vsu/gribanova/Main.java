package ru.vsu.gribanova;

public class Main {

    public static void main(String[] args) {

        long test1 = karatsuba(1234, 5678, 4);
        System.out.println(test1);
        long test2 = karatsuba(10, 10, 2);
        System.out.println(test2);
        long test3 = karatsuba(12345678, 12345678, 8);
        System.out.println(test3);
        long test4 = karatsuba(3, 7, 1);
        System.out.println(test4);

    }

    private static long karatsuba(long i, long j, int n) {
        if (i < 10 || j < 10) {
            return i * j;
        }
        if (n % 2 == 1)
            n++;
        long a = (long) (i / Math.pow(10, n / 2));
        long b = (long) (i % Math.pow(10, n / 2));
        long c = (long) (j / Math.pow(10, n / 2));
        long d = (long) (j % Math.pow(10, n / 2));

        long p = karatsuba(a, c, n / 2);
        long q = karatsuba(b, d, n / 2);
        long pq = karatsuba(a + b, c + d, n / 2);

        return ((long) ((p * Math.pow(10, n)) + ((pq - p - q) * Math.pow(10, n / 2)) + q));
    }
}
